/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entities.RendezVous;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ASUS
 */
public class RendezVousDao implements IDao<RendezVous> {

    private final Database dataBase = new Database();

    private final String SQL_INSERT = "INSERT INTO rendezvous "
            + " (nciPatient, typeDeService, objetService) "
            + " VALUES (?, ?, ?)";

    @Override
    public int insert(RendezVous rendezvous) {
        
        int id = 0;
        try {
            dataBase.openConnexion();
            dataBase.initPrepareStatement(SQL_INSERT);
            dataBase.getPs().setString(1, rendezvous.getPatient().getNci());
            //dataBase.getPs().setString(2, rendezvous.);
            dataBase.getPs().setString(3, rendezvous.getPatient().getNci());
            //dataBase.getPs().setInt(4, rendezvous.getConsultation().getId());
            //dataBase.getPs().setInt(5, rendezvous.getPrestation().getId());
            dataBase.executeUpdate(SQL_INSERT);
            ResultSet rs = dataBase.getPs().getGeneratedKeys();
            if (rs.next()) {
                id = rs.getInt(1);

            }
        } catch (SQLException ex) {
            Logger.getLogger(PatientDao.class
                    .getName()).log(Level.SEVERE, null, ex);
        } finally {
            dataBase.closeConnexion();
        }
        return id;
    }

    @Override
    public int update(RendezVous ogj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<RendezVous> findAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public RendezVous findById(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
