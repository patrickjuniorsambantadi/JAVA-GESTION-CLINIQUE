/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.time.LocalDate;

/**
 *
 * @author ASUS
 */
public class Consultation extends RendezVous{
    
    private String constantesPrises;
    private String typeMedecin;

    //Attribut Navigationnel
    private DossierMedical dossiermedical;
    private Medecin medecin;

    public Consultation(String constantesPrises, String typeMedecin, int id, LocalDate date, String heure) {
        super(id, date, heure);
        this.constantesPrises = constantesPrises;
        this.typeMedecin = typeMedecin;
    }

    public Consultation(String constantesPrises, String typeMedecin, LocalDate date, String heure) {
        super(date, heure);
        this.constantesPrises = constantesPrises;
        this.typeMedecin = typeMedecin;
    }
    
    public String getConstantesPrises() {
        return constantesPrises;
    }

    public void setConstantesPrises(String constantesPrises) {
        this.constantesPrises = constantesPrises;
    }

    public String getTypeMedecin() {
        return typeMedecin;
    }

    public void settypeMedecin(String typeMedecin) {
        this.typeMedecin = typeMedecin;
    }

    public DossierMedical getDossiermedical() {
        return dossiermedical;
    }

    public void setDossiermedical(DossierMedical dossiermedical) {
        this.dossiermedical = dossiermedical;
    }

    public Medecin getMedecin() {
        return medecin;
    }

    public void setMedecin(Medecin medecin) {
        this.medecin = medecin;
    }
    
    
    
}
