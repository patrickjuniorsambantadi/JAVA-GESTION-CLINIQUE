/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.time.LocalDate;
import java.util.Date;

/**
 *
 * @author ASUS
 */
public class RendezVous {

    private int id;
    private LocalDate date;
    private String heure;

    //Attribut Navigationnel
    private Patient patient;
    private Secretaire secretaire;

    
    public RendezVous() {
    }

    public RendezVous(int id, LocalDate date, String heure) {
        this.id = id;
        this.date = date;
        this.heure = heure;
    }

    public RendezVous(LocalDate date, String heure) {
        this.date = date;
        this.heure = heure;
    }

    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    

    public String getHeure() {
        return heure;
    }

    public void setHeure(String heure) {
        this.heure = heure;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public Secretaire getSecretaire() {
        return secretaire;
    }

    public void setSecretaire(Secretaire secretaire) {
        this.secretaire = secretaire;
    }


}
