/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.time.LocalDate;

/**
 *
 * @author ASUS
 */
public class Prestation extends RendezVous{
    
    private String nomPrestation;
    
    //Attribut Navigationnel
    private DossierMedical dossiermedical;
    private ResponsablePrestation responsableprestaion;

    public Prestation() { 
    }

    public Prestation(String nomPrestation, int id, LocalDate date, String heure) {
        super(id, date, heure);
        this.nomPrestation = nomPrestation;
    }

    public Prestation(String nomPrestation, LocalDate date, String heure) {
        super(date, heure);
        this.nomPrestation = nomPrestation;
    }

    

    public String getNomPrestation() {
        return nomPrestation;
    }

    public void setNomPrestation(String nomPrestation) {
        this.nomPrestation = nomPrestation;
    }

    public DossierMedical getDossiermedical() {
        return dossiermedical;
    }

    public void setDossiermedical(DossierMedical dossiermedical) {
        this.dossiermedical = dossiermedical;
    }

    public ResponsablePrestation getResponsableprestaion() {
        return responsableprestaion;
    }

    public void setResponsableprestaion(ResponsablePrestation responsableprestaion) {
        this.responsableprestaion = responsableprestaion;
    }
    
    
}
