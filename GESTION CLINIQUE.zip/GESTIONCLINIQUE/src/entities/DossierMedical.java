/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.util.List;


/**
 *
 * @author ASUS
 */
public class DossierMedical {
    
    private int id;
    
    //Attribut Navigationnel
    private Patient patient;
    public List<Consultation> consultation;
    public List<Prestation> prestation;

    public DossierMedical() {
    }

    public DossierMedical(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public List<Consultation> getConsultation() {
        return consultation;
    }

    public void setConsultation(List<Consultation> consultation) {
        this.consultation = consultation;
    }

    public List<Prestation> getPrestation() {
        return prestation;
    }

    public void setPrestation(List<Prestation> prestation) {
        this.prestation = prestation;
    }
    
    
    
}
