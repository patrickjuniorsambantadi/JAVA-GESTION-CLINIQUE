/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.util.List;

/**
 *
 * @author ASUS
 */
public class ResponsablePrestation extends User {
    
    private final String ROLE="ROLE_RESPONSABLE_PRESTATION";

    //Atribut Navigationnel
    private List<Prestation> prestation;
    
    
    
    //Constructeur
    public ResponsablePrestation() {
         this.role = ROLE;
    }

    public ResponsablePrestation(int id, String nom, String prenom, String login, String password) {
        super(id, nom, prenom, login, password);
        this.role = ROLE;
    }

    public ResponsablePrestation(String nom, String prenom, String login, String password) {
        super(nom, prenom, login, password);
    }

    
    
    

   
    public List<Prestation> getPrestation() {
        return prestation;
    }

    public void setPrestation(List<Prestation> prestation) {
        this.prestation = prestation;
    }
    
    

}
