/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import dao.PatientDao;
import dao.RendezVousDao;
import dao.UserDao;
import entities.Consultation;
import entities.DossierMedical;
import entities.Patient;
import entities.RendezVous;
import entities.User;
import java.time.LocalDate;
import java.util.List;

/**
 *
 * @author ASUS
 */
public class Service implements IService {

    UserDao daoUser = new UserDao();
    PatientDao daoPatient = new PatientDao();
    RendezVousDao daoRendezVous = new RendezVousDao();

    @Override
    public int planRendezVous(RendezVous rendezvous) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<RendezVous> searchAllRendezVous() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Consultation> searchAllConsultation() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Consultation> searchConsultationByDate(LocalDate date) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean deleteConsultation(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<DossierMedical> searchDossierMedical(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public User login(String login, String password) {
        return daoUser.findUserLoginAndPassword(login, password);
    }

    @Override
    public int addPatient(Patient patient) {
        if (patient.getId() == 0) {
            int id = daoPatient.insert(patient);
            patient.setId(id);
        }
        Patient pat = new Patient();
        return patient.getId();
    }

    @Override
    public int addRendezVous(RendezVous rendezvous) {
       if (rendezvous.getId() == 0) {
            int id = daoRendezVous.insert(rendezvous);
            rendezvous.setId(id);
        }
        RendezVous rv = new RendezVous();
        return rendezvous.getId();
    }


   
}
