/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import entities.Consultation;
import entities.DossierMedical;
import entities.Patient;
import entities.RendezVous;
import entities.User;
import java.time.LocalDate;
import java.util.List;

/**
 *
 * @author ASUS
 */
public interface IService {

    /*
    Ajout,modification,suppression boolean
        true ajout correct
        false Erreur
     */
//Medecin    
    /*Gerer consultation et rendezvous*/
    public int planRendezVous(RendezVous rendezvous);

    public List<RendezVous> searchAllRendezVous();

    public List<Consultation> searchAllConsultation();

    public List<Consultation> searchConsultationByDate(LocalDate date);

    public boolean deleteConsultation(int id);

    public List<DossierMedical> searchDossierMedical(int id);

//Patient
    public int addPatient(Patient patient);
    public int addRendezVous(RendezVous rendezvous);

    /*Gerer consultation et rendezvous*/

 /*Se connecter */
    public User login(String login, String password);

}
