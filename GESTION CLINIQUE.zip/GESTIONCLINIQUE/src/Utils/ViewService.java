/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Utils;

import javafx.scene.control.ComboBox;

/**
 *
 * @author ASUS
 */
public class ViewService {

    public static void loadComboBoxTypeRv(ComboBox<String> cboTypeRv) {
        cboTypeRv.getItems().add("Consultation");
        cboTypeRv.getItems().add("Prestation");
        cboTypeRv.getSelectionModel().selectFirst();
    }

    public static void loadComboBoxObjetConsultation(ComboBox<String> cboObjetRv) {
        cboObjetRv.setItems(null);
        cboObjetRv.getItems().add("Dentiste");
        cboObjetRv.getItems().add("Ophtalmologue");
        cboObjetRv.getItems().add("Chirurgien");
        cboObjetRv.getSelectionModel().selectFirst();
    }

    public static void loadComboBoxObjetPrestation(ComboBox<String> cboObjetRv) {
        cboObjetRv.setItems(null);
        cboObjetRv.getItems().add("Radio");
        cboObjetRv.getItems().add("Analyse"); 
        cboObjetRv.getSelectionModel().selectFirst();
    }
}
